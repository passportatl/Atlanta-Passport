// Background scheduler — runs periodic tasks at server startup.
//
// Tasks:
//   • Scheduled publish: every 5 minutes, auto-publish events whose
//     scheduledPublishAt has passed and workflowStatus is still "approved".
//   • Source auto-sync: every 6 hours, run ingestion for all active sources
//     that are due for a sync based on their per-source syncIntervalHours config.
//   • Past-event cleanup: every hour, archive ingested events whose date has
//     passed so they leave the admin pending queue and the public feed.
//
// All tasks are fire-and-forget; errors are logged but never crash the server.

import { and, eq, isNotNull, lte } from "drizzle-orm";
import { db, eventsTable, eventSourcesTable } from "@workspace/db";
import { enqueueSync, recoverStaleJobs } from "./ingestion/sync-queue";
import { notifyAdmin } from "./ingestion/health";
import { archivePastIngestedEvents } from "./ingestion/past-event-cleanup";
import { logger } from "./logger";

// ── Scheduled publish ─────────────────────────────────────────────────────────

async function runScheduledPublish(): Promise<void> {
  const now = new Date();

  const due = await db
    .select({ id: eventsTable.id, name: eventsTable.name })
    .from(eventsTable)
    .where(
      and(
        eq(eventsTable.workflowStatus, "approved"),
        isNotNull(eventsTable.scheduledPublishAt),
        lte(eventsTable.scheduledPublishAt, now),
      ),
    );

  if (due.length === 0) return;

  for (const event of due) {
    await db
      .update(eventsTable)
      .set({
        workflowStatus: "published",
        publishedAt: now,
        updatedAt: now,
      })
      .where(eq(eventsTable.id, event.id));
    logger.info({ eventId: event.id, name: event.name }, "Scheduled publish triggered");
  }

  logger.info({ count: due.length }, "Scheduled publish run complete");
}

// ── Source auto-sync ──────────────────────────────────────────────────────────

// Default sync interval per source type (hours)
const DEFAULT_SYNC_INTERVAL_BY_TYPE: Record<string, number> = {
  ical: 6,
  rss: 6,
  json_api: 6,
  csv_url: 24,
  google_sheets: 6,
  ticketmaster: 6,
  eventbrite: 6,
  meetup: 6,
  bandsintown: 12,
  seatgeek: 12,
};

function getSourceSyncIntervalHours(
  type: string,
  config: Record<string, unknown>,
  columnValue: number | null,
): number {
  // Admin-set column takes precedence, then legacy config value, then type default.
  if (typeof columnValue === "number" && columnValue > 0) return columnValue;
  const fromConfig = config.syncIntervalHours;
  if (typeof fromConfig === "number" && fromConfig > 0) return fromConfig;
  if (typeof fromConfig === "string") {
    const n = parseFloat(fromConfig);
    if (!isNaN(n) && n > 0) return n;
  }
  return DEFAULT_SYNC_INTERVAL_BY_TYPE[type] ?? 6;
}

async function runSourceAutoSync(): Promise<void> {
  const allActive = await db
    .select({
      id: eventSourcesTable.id,
      name: eventSourcesTable.name,
      type: eventSourcesTable.type,
      config: eventSourcesTable.config,
      lastSyncAt: eventSourcesTable.lastSyncAt,
      lastSyncStatus: eventSourcesTable.lastSyncStatus,
      healthStatus: eventSourcesTable.healthStatus,
      backoffUntil: eventSourcesTable.backoffUntil,
      priority: eventSourcesTable.priority,
      syncIntervalHours: eventSourcesTable.syncIntervalHours,
    })
    .from(eventSourcesTable)
    .where(eq(eventSourcesTable.isActive, true));

  const now = Date.now();
  const due = allActive.filter((source) => {
    // A source stuck in "running" is handled by the queue's dedup — skip.
    if (source.lastSyncStatus === "running") return false;
    // Auth failures never auto-retry: a human must fix credentials first.
    if (source.healthStatus === "awaiting_credentials") return false;
    // Respect retry backoff windows.
    if (source.backoffUntil && new Date(source.backoffUntil).getTime() > now) return false;

    let config: Record<string, unknown> = {};
    try {
      config = JSON.parse(source.config ?? "{}") as Record<string, unknown>;
    } catch {
      // ignore malformed config
    }
    const intervalMs =
      getSourceSyncIntervalHours(source.type, config, source.syncIntervalHours) * 3_600_000;

    if (!source.lastSyncAt) return true; // never synced → always due
    return now - new Date(source.lastSyncAt).getTime() >= intervalMs;
  });

  if (due.length === 0) {
    logger.info("Source auto-sync: no sources due");
    return;
  }

  logger.info({ count: due.length }, "Source auto-sync: enqueueing due sources");

  for (const source of due) {
    try {
      const enq = await enqueueSync({
        sourceId: source.id,
        sourceName: source.name,
        trigger: "scheduled",
        priority: source.priority ?? 5,
      });
      if ("alreadyQueued" in enq) continue;
      // Track completion in the background — update the failure-alert banner
      // once the job finishes (the queue owns retries/backoff).
      void enq.promise.then((result) => {
        if (result.status === "failed") {
          void flagSyncFailure(source.id, source.name, result.errorMessage ?? "Sync failed").catch(
            (err) => logger.error({ sourceId: source.id, err }, "Failed to record sync failure alert"),
          );
        } else if (result.status !== "cancelled") {
          void updateFailureAlert(source.id, source.name).catch((err) =>
            logger.error({ sourceId: source.id, err }, "Failed to update failure alert"),
          );
        }
      });
    } catch (err) {
      logger.error({ sourceId: source.id, name: source.name, err }, "Failed to enqueue auto-sync");
      await notifyAdmin({
        type: "scheduler_failure",
        severity: "critical",
        title: `Scheduler failed to enqueue sync for ${source.name}`,
        body: err instanceof Error ? err.message : String(err),
        sourceId: source.id,
      });
    }
  }
}

// ── Sync failure alerts ───────────────────────────────────────────────────────
//
// When a scheduled sync fails, set syncFailureAlertAt so the admin dashboard can
// show a prominent banner. Set it only once per failure streak (only when it is
// currently null); a later successful sync clears it.

async function updateFailureAlert(sourceId: string, name: string): Promise<void> {
  const [row] = await db
    .select({
      lastSyncStatus: eventSourcesTable.lastSyncStatus,
      lastSyncMessage: eventSourcesTable.lastSyncMessage,
      syncFailureAlertAt: eventSourcesTable.syncFailureAlertAt,
    })
    .from(eventSourcesTable)
    .where(eq(eventSourcesTable.id, sourceId));
  if (!row) return;

  if (row.lastSyncStatus === "error") {
    await flagSyncFailure(sourceId, name, row.lastSyncMessage ?? "Sync failed");
  } else if (row.syncFailureAlertAt) {
    // Sync recovered — end the failure streak so a future failure alerts again.
    await db
      .update(eventSourcesTable)
      .set({ syncFailureAlertAt: null, syncFailureAlertDismissedAt: null, updatedAt: new Date() })
      .where(eq(eventSourcesTable.id, sourceId));
    logger.info({ sourceId, name }, "Sync failure alert cleared after successful sync");
  }
}

async function flagSyncFailure(sourceId: string, name: string, message: string): Promise<void> {
  const now = new Date();
  const [row] = await db
    .select({
      syncFailureAlertAt: eventSourcesTable.syncFailureAlertAt,
      lastSyncStatus: eventSourcesTable.lastSyncStatus,
    })
    .from(eventSourcesTable)
    .where(eq(eventSourcesTable.id, sourceId));
  if (!row) return;

  const updates: Record<string, unknown> = { updatedAt: now };
  // A thrown error can leave the source stuck in "running" — record the failure.
  if (row.lastSyncStatus !== "error") {
    updates.lastSyncStatus = "error";
    updates.lastSyncMessage = message;
  }
  // Only start a new alert if there isn't already an active failure streak.
  if (!row.syncFailureAlertAt) {
    updates.syncFailureAlertAt = now;
    updates.syncFailureAlertDismissedAt = null;
    logger.warn({ sourceId, name, message }, "Sync failure alert raised for admin");
  }
  await db.update(eventSourcesTable).set(updates).where(eq(eventSourcesTable.id, sourceId));
}

// ── Scheduler entry points ────────────────────────────────────────────────────

let scheduledPublishTimer: ReturnType<typeof setInterval> | null = null;
let sourceAutoSyncTimer: ReturnType<typeof setInterval> | null = null;
let pastEventCleanupTimer: ReturnType<typeof setInterval> | null = null;

export function startScheduledPublish(intervalMs = 5 * 60 * 1000): void {
  if (scheduledPublishTimer) return;
  void runScheduledPublish().catch((err) => logger.error({ err }, "Scheduled publish startup run failed"));
  scheduledPublishTimer = setInterval(() => {
    void runScheduledPublish().catch((err) => logger.error({ err }, "Scheduled publish failed"));
  }, intervalMs);
  logger.info({ intervalMs }, "Scheduled publish checker started");
}

export function startSourceAutoSync(intervalMs = 60 * 60 * 1000): void {
  if (sourceAutoSyncTimer) return;
  // Clean up jobs orphaned by a previous process before scheduling new work.
  void recoverStaleJobs();
  // Run once after a short delay to let server fully initialize
  setTimeout(() => {
    void runSourceAutoSync().catch((err) => logger.error({ err }, "Source auto-sync startup run failed"));
  }, 30_000);
  sourceAutoSyncTimer = setInterval(() => {
    void runSourceAutoSync().catch((err) => logger.error({ err }, "Source auto-sync failed"));
  }, intervalMs);
  logger.info({ intervalMs }, "Source auto-sync scheduler started");
}

export function startPastEventCleanup(intervalMs = 60 * 60 * 1000): void {
  if (pastEventCleanupTimer) return;
  void archivePastIngestedEvents().catch((err) =>
    logger.error({ err }, "Past-event cleanup startup run failed"),
  );
  pastEventCleanupTimer = setInterval(() => {
    void archivePastIngestedEvents().catch((err) =>
      logger.error({ err }, "Past-event cleanup failed"),
    );
  }, intervalMs);
  logger.info({ intervalMs }, "Past-event cleanup scheduler started");
}
